-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 26, 2020 at 06:19 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` int(11) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phonenumber` varchar(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `firstname`, `lastname`, `username`, `email`, `phonenumber`) VALUES
(1, 'James', 'Butt', 'jamesB', 'jbutt@gmail.com', '504-621-8927'),
(2, 'Josephine', 'Darkjy', 'josephineD', 'josephine_darakjy@darakjy.org', '810-292-9388'),
(3, 'Art', 'Venere', 'artV', 'art@venere.org', '856-636-8749'),
(4, 'Lenna', 'Paprocki', 'lenP', 'lpaprocki@hotmail.com', '907-385-4412'),
(5, 'Donette', 'Foller', 'donF', 'donette.foller@cox.net', '513-570-1893'),
(6, 'Simona', 'Morasca', 'simoM', 'simona@morasca.com', '419-503-2484'),
(7, 'Mitsue', 'Tollner', 'mitsT', 'mitsue_tollner@yahoo.com', '773-573-6914'),
(8, 'Leota', 'Dilliard', 'leoD', 'leota@hotmail.com', '408-752-3500'),
(9, 'Sage', 'Wieser', 'sagW', 'sage_wieser@cox.net', '605-414-2147'),
(10, 'Kris', 'Marrier', 'kriM', 'kris@gmail.com', '410-655-8723'),
(11, 'Minna', 'Amigon', 'minA', 'minna_amigon@yahoo.com', '215-874-1229'),
(12, 'Abel', 'Maclead', 'abeM', 'amaclead@gmail.com', '631-335-3414'),
(13, 'Kiley', 'Caldarera', 'kilC', 'kiley.caldarera@aol.com', '310-498-5651'),
(14, 'Graciela', 'Ruta', 'gracR', 'gruta@cox.net', '440-780-8425'),
(15, 'Meaghan', 'Garufi', 'meaG', 'meaghan@hotmail.com', '931-313-9635');

-- --------------------------------------------------------

--
-- Table structure for table `forex`
--

CREATE TABLE `forex` (
  `id` int(11) NOT NULL,
  `numCode` varchar(100) NOT NULL,
  `charCode` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `value` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `forex`
--

INSERT INTO `forex` (`id`, `numCode`, `charCode`, `name`, `value`, `date`) VALUES
(1, '036', 'AUD', 'Australian dollar', '50,7669', '24.07.2020'),
(2, '944', 'AZN', 'Azerbaijani manat', '41,7675', '24.07.2020'),
(3, '826', 'GBP', 'British pound ', '90,2224', '24.07.2020'),
(4, '051', 'AMD', 'Armenian dram', '14,6165', '24.07.2020'),
(5, '933', 'BYN', 'Belarusian ruble', '29,7764', '24.07.2020'),
(6, '975', 'BGN', 'Bulgarian lev', '42,0322', '24.07.2020'),
(7, '986', 'BRL', 'Brazilian real', '13,8610', '24.07.2020'),
(8, '348', 'HUF', 'Hungarian forint', '23,6674', '24.07.2020'),
(9, '344', 'HKD', 'Hong Kong dollar', '91,5451', '24.07.2020'),
(10, '208', 'DKK', 'Danish krone', '11,0438', '24.07.2020'),
(11, '840', 'USD', 'United States dollar', '70,9630', '24.07.2020'),
(12, '978', 'EUR', 'Euro', '82,1893', '24.07.2020'),
(13, '356', 'INR', 'Indian rupee', '94,9319', '24.07.2020'),
(14, '398', 'KZT', 'Kazakhstani tenge', '17,1707', '24.07.2020'),
(15, '124', 'CAD', 'Canadian dollar', '53,0525', '24.07.2020'),
(16, '417', 'KGS', 'Kyrgyzstani som', '91,8615', '24.07.2020'),
(17, '156', 'CNY', 'Chinese yuan', '10,1424', '24.07.2020'),
(18, '498', 'MDL', 'Moldovan leu', '42,0397', '24.07.2020'),
(19, '578', 'NOK', 'Norwegian krone', '77,8035', '24.07.2020'),
(20, '985', 'PLN', 'Polish z?oty', '18,6269', '24.07.2020'),
(21, '946', 'RON', 'Romanian leu', '17,0032', '24.07.2020'),
(22, '960', 'XDR', 'SDR (Special Drawing Rights)', '99,0480', '24.07.2020'),
(23, '702', 'SGD', 'Singapore dollar', '51,3035', '24.07.2020'),
(24, '972', 'TJS', 'Tajikistani somoni', '68,8460', '24.07.2020'),
(25, '949', 'TRY', 'Turkish lira', '10,3626', '24.07.2020'),
(26, '934', 'TMT', 'Turkmenistan manat', '20,3041', '24.07.2020'),
(27, '860', 'UZS', 'Uzbekistani so?m', '69,5008', '24.07.2020'),
(28, '980', 'UAH', 'Ukrainian hryvnia', '25,4381', '24.07.2020'),
(29, '203', 'CZK', 'Czech koruna', '31,2420', '24.07.2020'),
(30, '752', 'SEK', 'Swedish krona', '80,2032', '24.07.2020'),
(31, '756', 'CHF', 'Swiss franc', '76,3947', '24.07.2020'),
(32, '710', 'ZAR', 'South African rand', '43,1011', '24.07.2020'),
(33, '410', 'KRW', 'South Korean won', '59,3113', '24.07.2020'),
(34, '392', 'JPY', 'Japanese yen', '66,2123', '24.07.2020');

-- --------------------------------------------------------

--
-- Table structure for table `personal_contacts`
--

CREATE TABLE `personal_contacts` (
  `id` int(11) NOT NULL,
  `contact_username` varchar(100) NOT NULL,
  `u_username` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `personal_contacts`
--

INSERT INTO `personal_contacts` (`id`, `contact_username`, `u_username`) VALUES
(1, 'jamesB', 'karlernest'),
(2, 'josephineD', 'karlernest'),
(3, 'artV', 'karlernest'),
(4, 'lenP', 'karlernest'),
(5, 'donF', 'brettsurell'),
(6, 'simoM', 'brettsurell'),
(7, 'mitsT', 'brettsurell'),
(8, 'leoD', 'brettsurell'),
(9, 'sagW', 'kimhermosura'),
(10, 'kriM', 'kimhermosura'),
(11, 'minA', 'kimhermosura'),
(12, 'abeM', 'kimhermosura'),
(13, 'kilC', 'kimhermosura'),
(14, 'gracR', 'kimhermosura'),
(15, 'meaG', 'kimhermosura');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstname`, `lastname`, `username`, `email`, `password`) VALUES
(1, 'brett', 'surell', 'brettsurell', 'brettsurell@gmail.com', 'c1bed8b1918ccdb44d150653e96b4942'),
(2, 'Karl', 'Raymundo', 'karlernest', 'karlernestraymundo@gmail.com', 'aff930faed21cd7ac42c156b08505133'),
(3, 'Kim', 'Hermosura', 'kimhermosura', 'kim@gmail.com', '24f692faa3ac0ded1c7a57119c50ab53');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `forex`
--
ALTER TABLE `forex`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `personal_contacts`
--
ALTER TABLE `personal_contacts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `contact_username` (`contact_username`),
  ADD KEY `u_username` (`u_username`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`,`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `forex`
--
ALTER TABLE `forex`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `personal_contacts`
--
ALTER TABLE `personal_contacts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `personal_contacts`
--
ALTER TABLE `personal_contacts`
  ADD CONSTRAINT `personal_contacts_ibfk_1` FOREIGN KEY (`u_username`) REFERENCES `users` (`username`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `personal_contacts_ibfk_2` FOREIGN KEY (`contact_username`) REFERENCES `contacts` (`username`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
