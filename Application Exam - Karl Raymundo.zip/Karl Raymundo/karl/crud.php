<?php 

$db = mysqli_connect('localhost', 'root', '', 'test');

	// initialize variables

$firstname 		= "";
$lastname 		= "";
$username 		= "";
$email 			= "";
$phonenumber 	= "";

$id = 0;
$update = false;
$add = false;



//////////////////////SAVE///////////////////////////////////////////
if (isset($_POST['save'])) {

	$firstname 		= $_POST['firstname'];
	$lastname 		= $_POST['lastname'];
	$username 		= $_POST['username'];
	$email 			= $_POST['email'];
	$phonenumber 	= $_POST['phonenumber'];




	$savesql = "INSERT INTO contacts (firstname, lastname,username,email,phonenumber)
	VALUES ('$firstname', '$lastname','$username','$email','$phonenumber')";

	mysqli_query($db, $savesql); 

	$_SESSION['message'] = "Contact saved"; 
	header('location: index.php');

	
}

///////////////////////////////////////////////////////////////////////	////

//////////////////////ADD  ///////////////////////////////////////////

if (isset($_POST['add'])) {
	$contact_username 		= $_POST['contact_username'];
	$u_username 			= $_POST['u_username'];


	$savesql2 = "INSERT INTO personal_contacts (contact_username, u_username) 
	VALUES ('$contact_username', '$u_username')";

	mysqli_query($db, $savesql2); 

	$_SESSION['message'] = "Contact saved"; 
	header('location: index.php');

	
	
}

///////////////////////////////////////////////////////////////////////////









//////////////////////UPDATE///////////////////////////////////////////

if (isset($_POST['update'])) {
	$firstname 			= $_POST['firstname'];
	$lastname 			= $_POST['lastname'];
	$username 			= $_POST['username'];
	$email 				= $_POST['email'];
	$phonenumber 		= $_POST['phonenumber'];
	$id 				= $_POST['id'];

	$updatesql= "UPDATE contacts SET firstname='$firstname', lastname='$lastname',username='$username',email='$email',phonenumber='$phonenumber' WHERE id=$id";

	mysqli_query($db,$updatesql);
	$_SESSION['message'] = "Contact updated!"; 
	header('location: index.php');
}


/////////////////////////////////////////////////////////////////




//////////////////////DELETE///////////////////////////////////////////

if (isset($_GET['del'])) {
	$id = $_GET['del'];
	$delsql = "DELETE FROM contacts WHERE id=$id";
	mysqli_query($db, $delsql);
	$_SESSION['message'] = "Address deleted!"; 
	header('location: index.php');
}

$sql = "SELECT * FROM contacts";
$results = mysqli_query($db, $sql);




//////////////////////DELETE PERSONAL CONTACT///////////////////////////////////////////

if (isset($_GET['del2'])) {
	$id = $_GET['del2'];
	$delsql = "DELETE FROM personal_contacts WHERE id=$id";
	mysqli_query($db, $delsql);
	$_SESSION['message'] = "Address deleted!"; 
	header('location: index.php');
}


















?>

