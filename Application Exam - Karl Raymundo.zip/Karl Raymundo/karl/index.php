<!------------------Session------------------->
<?php 
session_start(); 

if (!isset($_SESSION['username'])) {
    $_SESSION['msg'] = "You must log in first";
    header('location: login.php');
}

if (isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['username']);
    header("location: login.php");
}

?>



<!------------------------------------------->
<?php 
include('crud.php');

if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $update = true;
    $record = mysqli_query($db, "SELECT * FROM contacts WHERE id=$id");

        //if (count($record) == 0) {


    if($record->num_rows){
        $n = mysqli_fetch_array($record);
        $firstname = $n['firstname'];
        $lastname = $n['lastname'];
        $username = $n['username'];
        $email = $n['email'];
        $phonenumber = $n['phonenumber'];
    }

}
/////////////////////////////////////////////////
/*
if (isset($_GET['add'])) {
    $id = $_GET['add'];
    $add = true;
    $user = $_POST['u_username'];

   $username        = $_POST['username'];


    $record2 = mysqli_query($db, "INSERT INTO personal_contacts (`username`, `u_username`) VALUES ( '$username', '$user')");

        //if (count($record) == 0) {


    if($record2->num_rows){
        $pc = mysqli_fetch_array($record);
        $username = $pc['username'];
        $user = $pc['u_username'];
        }

}

*/



?>


<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Application Exam - Karl Raymundo</title>

<!-- 

Sentra Template

https://templatemo.com/tm-518-sentra

-->
<meta name="description" content="">
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css"  rel="stylesheet">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/bootstrap-theme.min.css">
<link rel="stylesheet" href="css/fontAwesome.css">
<link rel="stylesheet" href="css/light-box.css">
<link rel="stylesheet" href="css/owl-carousel.css">
<link rel="stylesheet" href="css/templatemo-style.css">

<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">

<script src="js/vendor/modernizr-2.8.3-respond-1.4.2.min.js"></script>






</head>

<body>


    <!-- notification message -->
    <?php if (isset($_SESSION['success'])) : ?>
      <div class="error success" >
        <h3>
          <?php 
          echo $_SESSION['success']; 
          unset($_SESSION['success']);
          ?>
      </h3>
  </div>
<?php endif ?>

<div class="sidebar-navigation hidden-sm hidden-xs">

    <div class="logo">
        <a href="#"><em>Hello! </em><?php echo $_SESSION['username']; ?></a>
    </div>

    <nav>
        <ul>
                  <!---
                    <li>
                        <a href="#top">
                            <span class="rect"></span>
                            <span class="circle"></span>
                            Home
                        </a>
                    </li>
                -->
                 <!---
                  <li>
                    <a href="#featured">
                        <span class="rect"></span>
                        <span class="circle"></span>
                        Featured
                    </a>
                </li>
                -->

                <li>
                    <a href="#projects">
                        <span class="rect"></span>
                        <span class="circle"></span>
                        General Contacts
                    </a>
                </li>
                <li>
                    <a href="#video">
                        <span class="rect"></span>
                        <span class="circle"></span>
                        Personal Contacts
                    </a>
                </li>





                <li>
                    <a href="#contact">
                        <span class="rect"></span>
                        <span class="circle"></span>
                        Add Contacts
                    </a>
                </li>



                <li>
                    <a href="#blog">
                        <span class="rect"></span>
                        <span class="circle"></span>
                        Forex
                    </a>
                </li>


            </ul>
        </nav>

        <style type="text/css">
            .bottomleft {
              position: absolute;
              bottom: 0px;
              left: -1px;
              font-size: 18px;
              padding: 0px
              margin:auto;
          }

      </style>

      <div class="logo bottomleft" >
        <a href="login.php?logout='1'"><em> </em>Logout</a>
    </div>

</div>

<div class="page-content">






    <!---------------HOME------------------------->

   
        <!-------------------------END OF HOME---------------------->







        <!--------------------GENERAL CONTACTS VIEW LIST ------------------->




        <section id="projects" class="content-section">
            <div class="section-heading">
                <h1><em>General <em>Contacts</em></h1>

            </div>
            <div class="section-content">


                <div class="table-responsive">
                    <table id= "table1" class="table">
                        <thead>
                            <tr>


                                <th><h3><center>No.</center></h3></th>
                                <th><h3><center>First Name</center></h3></th>
                                <th><h3><center>Last Name</center></h3></th>
                                <th><h3><center>Username</center></h3></th>
                                <th><h3><center>Email</center></h3></th>
                                <th><h3><center>Phone Number</center></h3></th>
                                <th colspan"2"><h3><center>Action</center></h3></th>
                            </tr>
                        </thead>
                        <tbody>
                         <?php $results = mysqli_query($db, "SELECT * FROM contacts"); ?>
                         <?php while ($row = mysqli_fetch_array($results)) { ?>
                            <tr>
                                <td><?php echo $row['id']; ?></td>
                                <td><?php echo $row['firstname']; ?></td>
                                <td><?php echo $row['lastname']; ?></td>
                                <td><?php echo $row['username']; ?></td>
                                <td><?php echo $row['email']; ?></td>
                                <td><?php echo $row['phonenumber']; ?></td>

                                <td>
                                    <a href="index.php?edit=<?php echo $row['id']; ?> #contact" >
                                        <button class="btn btn-primary" type="button">Edit</button>
                                    </a>
                                </td>

                                <td>
                                    <a href="crud.php?del=<?php echo $row['id']; ?>" >
                                       <button class="btn btn-primary" type="button"> Delete</button>
                                   </a>
                               </td>

                           </tr>
                       </tbody>
                   <?php } ?>
               </table>

           </div>
       </section>

       <!---------------------------------END OF GENERAL CONTACTS VIEW LIST -------->






       <!--------------------Personal CONTACTS VIEW LIST ------------------->




       <section id="video" class="content-section">
        <div class="section-heading">
            <h1><em>Personal <em>Contacts</em></h1>

        </div>
        <div class="section-content">


            <div class="table-responsive">
                <table id= "table1" class="table">
                    <thead>
                        <tr>


                            <th><center>Number</center></th>
                            <th><center>Contact Name</center></th>

                            <th><center>Username</center></th>
                            <th><center>Email</center></th>
                            <th><center>Phone Number</center></th>
                            <th><center>Action</center></th>
                        </tr>
                    </thead>

                    <tbody>



                     <?php 

                     $user = $_SESSION['username'];

                     $sqlpc = "SELECT CONCAT(gc.firstname,', ', gc.lastname,' ') AS contact_name,
                     pc.id,
                     pc.contact_username,
                     gc.email,
                     gc.phonenumber,
                     pc.u_username

                     FROM
                     personal_contacts AS pc
                     INNER JOIN contacts AS gc
                     ON
                     pc.contact_username = gc.username
                     where pc.u_username='$user'";
                     $results2 = mysqli_query($db,$sqlpc );


                     ?>

                     <?php while ($row = mysqli_fetch_array($results2)) { ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td><?php echo $row['contact_name']; ?></td>

                            <td><?php echo $row['contact_username']; ?></td>
                            <td><?php echo $row['email']; ?></td>
                            <td><?php echo $row['phonenumber']; ?></td>
                                <!--<td>
                                    <a href="index.php?edit=<?php echo $row['id']; ?> #contact" class="edit_btn" >Edit</a>
                                </td>-->
                                <td>
                                    <a href="crud.php?del=<?php echo $row['id']; ?>" class="del_btn">
                                       <button class="btn btn-primary" type="button"> Delete</button>
                                   </a>
                               </td>
                           </tr>
                       </tbody>
                   <?php } ?>
               </table>

           </div>
       </section>


       <!---------------------------------END OF Personal CONTACTS VIEW LIST -------->
















<!-----------------------------------------
        <section id="video" class="content-section">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-heading">
                        <h1>This is a <em>company</em> presentation.</h1>
                        <p>Praesent pellentesque efficitur magna, sed pellentesque neque malesuada vitae.</p>
                    </div>
                    <div class="text-content">
                        <p>In eget ipsum sed lorem vehicula luctus. Curabitur non dolor rhoncus, hendrerit justo sit amet, vestibulum turpis. Pellentesque id auctor tellus, vel ultricies augue. Duis condimentum aliquet blandit. Fusce rhoncus et eros ut pharetra. Phasellus convallis ultricies ligula ac gravida.</p>
                    </div>
                    <div class="accent-button button">
                        <a href="#blog">Continue Reading</a>
                    </div>
                </div>

                <div class="col-md-12">
                    <div class="box-video">
                        <div class="bg-video" style="background-image: url(https://unsplash.imgix.net/photo-1425036458755-dc303a604201?fit=crop&fm=jpg&q=75&w=1000);">
                            <div class="bt-play">Play</div>
                        </div>
                        <div class="video-container">
                            <iframe width="100%" height="520" src="https://www.youtube.com/embed/j-_7Ub-Zkow?rel=0&amp;showinfo=0" frameborder="0" allowfullscreen="allowfullscreen"></iframe>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        ----------------------------------------- ---->






        <!------ADD GENERAL CONTACTS------->

        <section id="contact" class="content-section">

            <style type="text/css">
                label {color: Black;font-size:20px;}
            </style>

            <div id="contact-content">
                <div class="section-heading">
                    <h1>Add to<em> Contacts</em></h1>
                </div>


                <div class="section-content">
                    <form id="contact" action="crud.php" method="post">
                     <input type="hidden" name="id" value="<?php echo $id; ?>">
                     <div class="row">
                        <div class="col-md-6">
                          <fieldset>
                            <label>First Name:</label>
                            <input style="  color: red; 
                            font-size:20px;
                            border:1px; 
                            border-style: solid;
                            border-color:black;" 

                            name="firstname" type="text" class="form-control" 
                            placeholder="Enter First Name..." value="<?php echo $firstname; ?>" required>
                        </fieldset>
                    </div>

                    <div class="col-md-6">
                      <fieldset>
                        <label>Last Name:</label>
                        <input style="  color: red; 
                        font-size:20px;
                        border:1px; 
                        border-style: solid;
                        border-color:black;" 
                        name="lastname" rows="6" class="form-control" 
                        placeholder="Enter Last Name..." value="<?php echo $lastname; ?>" required>
                    </fieldset>
                </div>

                <div class="col-md-6">
                  <fieldset>
                    <label>Username:</label>
                    <input style="  color: red; 
                    font-size:20px;
                    border:1px; 
                    border-style: solid;
                    border-color:black;" 
                    name="username" type="text" class="form-control" 
                    placeholder="Enter Username..." value="<?php echo $username; ?>" required>
                </fieldset>
            </div>

            <div class="col-md-6">
              <fieldset>
                 <label>Email:</label>
                 <input style="  color: red; 
                 font-size:20px;
                 border:1px; 
                 border-style: solid;
                 border-color:black;" name="email" type="email" class="form-control" 
                 placeholder="Enter email..." value="<?php echo $email; ?>"required>
             </fieldset>
         </div>



         <div class="col-md-12">
          <fieldset>
             <label>Phone Number:</label>
             <input style="  color: red; 
             font-size:20px;
             border:1px; 
             border-style: solid;
             border-color:black;" name="phonenumber" type="text" class="form-control" 
             placeholder="Enter Phone Number..." value="<?php echo $phonenumber; ?>"required>
         </fieldset>
     </div>

     <div class="col-md-6">
      <fieldset>
        <?php if ($update == true): ?>
            <button  class="btn" type="submit" id="update" name="update">Update Info</button>
            <?php else: ?>
                <button  class="btn" type="submit" id="save" name="save">Save to General Contacts</button>
            <?php endif ?>

        </fieldset>
    </div>

    <div class="col-md-6">
      <fieldset>


        <button  class="btn" type="submit" id="add" name="add">Add to Personal Contacts</button>


    </fieldset>
</div>


</div>
</form>
</div>
</div>
</section>
<!-------------------------END OF ADD CONTACTS---------------------->










 <!------ADD PERSONAL CONTACTS-------

        <section id="contact" class="content-section">

            <style type="text/css">
                label {color: Black;font-size:20px;}
            </style>

            <div id="contact-content">
                <div class="section-heading">
                    <h1>Add to<em> Personal Contacts</em></h1>
                </div>


                <div class="section-content">
                    <form id="contact" action="crud.php" method="post">
                     <input type="hidden" name="id" value="<?php echo $id; ?>">
                     <div class="row">
                        <div class="col-md-6">
                          <fieldset>
                            <label>First Name:</label>
                            <input style="  color: red; 
                            font-size:20px;
                            border:1px; 
                            border-style: solid;
                            border-color:black;" 

                            name="firstname" type="text" class="form-control" 
                            placeholder="Enter First Name..." value="<?php echo $firstname; ?>" required>
                        </fieldset>
                    </div>

                    <div class="col-md-6">
                      <fieldset>
                        <label>Last Name:</label>
                        <input style="  color: red; 
                        font-size:20px;
                        border:1px; 
                        border-style: solid;
                        border-color:black;" 
                        name="lastname" rows="6" class="form-control" 
                        placeholder="Enter Last Name..." value="<?php echo $lastname; ?>" required>
                    </fieldset>
                </div>

                <div class="col-md-6">
                  <fieldset>
                    <label>Username:</label>
                    <input style="  color: red; 
                    font-size:20px;
                    border:1px; 
                    border-style: solid;
                    border-color:black;" 
                    name="username" type="text" class="form-control" 
                    placeholder="Enter Username..." value="<?php echo $username; ?>" required>
                </fieldset>
            </div>

            <div class="col-md-6">
              <fieldset>
                 <label>Email:</label>
                 <input style="  color: red; 
                 font-size:20px;
                 border:1px; 
                 border-style: solid;
                 border-color:black;" name="email" type="email" class="form-control" 
                 placeholder="Enter email..." value="<?php echo $email; ?>"required>
             </fieldset>
         </div>



         <div class="col-md-6">
          <fieldset>
             <label>Phone Number:</label>
             <input style="  color: red; 
             font-size:20px;
             border:1px; 
             border-style: solid;
             border-color:black;" name="phonenumber" type="text" class="form-control" 
             placeholder="Enter Phone Number..." value="<?php echo $phonenumber; ?>"required>
         </fieldset>
     </div>

     <div class="col-md-12">
      <fieldset>
        <?php if ($update == true): ?>
            <button  class="btn" type="submit" id="update" name="update">Update Info</button>
            <?php else: ?>
                <button  class="btn" type="submit" id="save" name="save">Save to General Contacts</button>
            <?php endif ?>

        </fieldset>
    </div>

</div>
</form>
</div>
</div>
</section>
---------------------END OF ADD CONTACTS---------------------->




<section id="blog" class="content-section">
    <div class="section-heading">
        <h1><em><em>Forex</em></h1>

    </div>
    <div class="container">
        <form method="POST">


            <div class="form-group">
                <label>FROM</label>
                <input name="from" class="form-control">
            </div>

             <div class="form-group">
                <label>TO</label>
                <input name="to" class="form-control">
            </div>

             <div class="form-group">
                <label>AMOUNT</label>
                <input name="amount" class="form-control">
            </div>
              <div class="form-group">
                <label>CONVERTED AMOUNT</label>

                    <?php 
    if (isset($_POST["submit"]))
    {
        $from       =$_POST['from'];
        $to         =$_POST['to'];
        $amount     =$_POST['amount'];

        $string     =$from . "_" . $to;

        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://free.currconv.com/api/v7/convert?q=$string&compact=ultra&apiKey=9fca292ed86eafb34779",
            CURLOPT_RETURNTRANSFER => 1

        ));

        $response = curl_exec($curl);
        $response = json_decode($response,true );
        $rate = $response[$string];
        $total = $rate * $amount;

       
     echo "<p class='form-control'> $amount $from = $total $to </p>";
        //print_r($total);
    }
    
?>


              
            </div>

            <input type="submit" name="submit" class="btn btn-primary" value="Convert">

        </form>
    </div>
    <br><br><br>
    <div class="section-content">


        <div class="table-responsive">
            <table id= "table3" class="table">
                <thead>
                    <tr>
                        <th><center>Numeric code</center></th>
                        <th><center>Letter code<center></th>
                            <th><center>Currency name</center></th>
                            <th><center>Forex rate</center></th>
                            <th><center>Time of forex rate</center></th>
                        </tr>
                    </thead>

                    <tbody>



                     <?php 

                     $user = $_SESSION['username'];

                     $sqlpc = "SELECT * FROM forex";
                     $results2 = mysqli_query($db,$sqlpc );


                     ?>

                     <?php while ($row = mysqli_fetch_array($results2)) { ?>
                        <tr>
                            <td><?php echo $row['numCode']; ?></td>
                            <td><?php echo $row['charCode']; ?></td>

                            <td><?php echo $row['name']; ?></td>
                            <td><?php echo $row['value']; ?></td>
                            <td><?php echo $row['date']; ?></td>


                        </tr>
                    </tbody>
                <?php } ?>
            </table>

        </div>
    </section>


    <!---------------------------------END OF Personal CONTACTS VIEW LIST -------->













    <!------------------------------------------------------------------------------------------------>




    <section class="footer">
        <p>Copyright &copy; 2019 Company Name 

        . Design: TemplateMo</p>
    </section>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<script>window.jQuery || document.write('<script src="js/vendor/jquery-1.11.2.min.js"><\/script>')</script>

<script src="js/vendor/bootstrap.min.js"></script>

<script src="js/plugins.js"></script>
<script src="js/main.js"></script>

<script>
        // Hide Header on on scroll down
        var didScroll;
        var lastScrollTop = 0;
        var delta = 5;
        var navbarHeight = $('header').outerHeight();

        $(window).scroll(function(event){
            didScroll = true;
        });

        setInterval(function() {
            if (didScroll) {
                hasScrolled();
                didScroll = false;
            }
        }, 250);

        function hasScrolled() {
            var st = $(this).scrollTop();
            
            // Make sure they scroll more than delta
            if(Math.abs(lastScrollTop - st) <= delta)
                return;
            
            // If they scrolled down and are past the navbar, add class .nav-up.
            // This is necessary so you never see what is "behind" the navbar.
            if (st > lastScrollTop && st > navbarHeight){
                // Scroll Down
                $('header').removeClass('nav-down').addClass('nav-up');
            } else {
                // Scroll Up
                if(st + $(window).height() < $(document).height()) {
                    $('header').removeClass('nav-up').addClass('nav-down');
                }
            }
            
            lastScrollTop = st;
        }
    </script>

    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js" type="text/javascript"></script>

    <script type="text/javascript">
        $(document).ready(function() {
            $('#table1').DataTable();
        } );



    </script>



</body>
</html>