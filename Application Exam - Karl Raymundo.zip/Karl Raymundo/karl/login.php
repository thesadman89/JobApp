<?php include('server.php') ?>


<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>CodePen - Weekly Coding Challenge #1 -  Double slider Sign in/up Form - Desktop Only</title>
  <link rel="stylesheet" href="./login_style.css">

 
</head>
<body>


<!-- partial:index.partial.html -->
<?php include('errors.php'); ?>




<div class="container" id="container">
	<div class="form-container sign-up-container">
		<form method="post" action="login.php">
			<h1>Create Account</h1>
			
			
			
			<input type="text" name="firstname" placeholder="First Name" />
			<input type="text" name="lastname" placeholder="Last Name"/>
			<input type="text" name="username" placeholder="Username" />
			<input type="email" name="email" placeholder="Email" />
			<input type="password" name="password_1" placeholder="Password" />
			<input type="password" name="password_2" placeholder="Confirm Password " />


			<button type="submit" name="reg_user">Sign Up</button>
		</form>
	</div>
	<div class="form-container sign-in-container">
		<form method="post" action="login.php">
			<h1>Sign in</h1>
			<br><br>
			<input type="text" name="username"placeholder="Enter Username" />
			<input type="password" name="password"placeholder="Password"/>
			<br>
			<button name="login_user" type="submit">Sign In</button>

		</form>
	</div>


	<div class="overlay-container">
		<div class="overlay">
			<div class="overlay-panel overlay-left">
				<h1>Welcome Back!</h1>
				<p>To keep connected with us please login with your personal info</p>
				<button class="ghost" id="signIn">Sign In</button>
			</div>
			<div class="overlay-panel overlay-right">
				<h1>Hello, Friend!</h1>
				<p>Enter your personal details and start journey with us</p>
				<button class="ghost" id="signUp" >Sign Up</button>
			</div>
		</div>
	</div>
</div>

<footer>
	<p>
		Created with <i class="fa fa-heart"></i> by
		<a target="_blank" href="https://florin-pop.com">Florin Pop</a>
		- Read how I created this and how you can join the challenge
		<a target="_blank" href="https://www.florin-pop.com/blog/2019/03/double-slider-sign-in-up-form/">here</a>.
	</p>
</footer>
<!-- partial -->




  <script>
	  const signUpButton = document.getElementById('signUp');
const signInButton = document.getElementById('signIn');
const container = document.getElementById('container');

signUpButton.addEventListener('click', () => {
	container.classList.add("right-panel-active");
});

signInButton.addEventListener('click', () => {
	container.classList.remove("right-panel-active");
});
  </script>

</body>
</html>
